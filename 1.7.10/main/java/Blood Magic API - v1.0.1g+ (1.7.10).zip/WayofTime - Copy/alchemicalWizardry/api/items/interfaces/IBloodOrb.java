package WayofTime.alchemicalWizardry.api.items.interfaces;

public interface IBloodOrb 
{
	public int getMaxEssence();
	
	public int getOrbLevel();
}
