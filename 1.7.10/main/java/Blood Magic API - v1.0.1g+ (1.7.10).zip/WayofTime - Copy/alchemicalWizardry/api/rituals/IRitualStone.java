package WayofTime.alchemicalWizardry.api.rituals;

public interface IRitualStone 
{

}
